﻿//определим базовый класс и в нем шаблонный метод CreateSmartphone
//определяем сами методы-этапы сoздания смартфона  не реализууя их
namespace TemplateMethod
{
    /// <summary>
    /// Базовый класс смартфона.
    /// </summary>
    public abstract class PhoneBase
    {
        /// <summary>
        /// создать смартфон.
        /// </summary>
        public void CreateSmartphone()
        {
            CreateHardware();
            Collect();
            Install();
        }

        /// <summary>
        /// Произвести железо.
        /// </summary>
        protected abstract void CreateHardware();

        /// <summary>
        /// Собрать железо.
        /// </summary>
        protected abstract void Collect();

        /// <summary>
        /// Установить ПО.
        /// </summary>
        protected abstract void Install();
    }
}
