﻿using System;
using System.Text;
//экземпляры классов, вызываем шаблонный метод, но не обращаемся к этапам производства смартфона
namespace TemplateMethod
{
    class ProgramTemplate
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // Создаем два вида смартфонов
            var androidphone = new androidphone();
            var iosphone = new iosphone();

            // создаем смартфон на базе android.
            Console.WriteLine(androidphone);
            androidphone.CreateSmartphone();
            Console.ReadLine();

            // создаем смартфон на базе ios.
            Console.WriteLine(iosphone);
            iosphone.CreateSmartphone();
            Console.ReadLine();
        }
    }
}
