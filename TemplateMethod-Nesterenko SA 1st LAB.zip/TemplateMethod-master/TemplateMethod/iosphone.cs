﻿using System;
//класс наследник
namespace TemplateMethod
{
    public class iosphone : PhoneBase
    {
        /// <inheritdoc />
        protected override void CreateHardware()
        {
            Console.WriteLine("Создаем ПО с помощью Apple.");
        }

        /// <inheritdoc />
        protected override void Collect()
        {
            Console.WriteLine("Собираем смартфон на заводе Apple.");
        }

        /// <inheritdoc />
        protected override void Install()
        {
            Console.WriteLine("Устанавливаем ПО ios.");
        }

        /// <summary>
        /// Приведение объекта к строке.
        /// </summary>
        /// <returns> Тип смартфона. </returns>
        public override string ToString()
        {
            return "Смартфон на ios";
        }
    }
}
