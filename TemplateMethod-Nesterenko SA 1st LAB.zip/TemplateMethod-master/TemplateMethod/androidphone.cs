﻿using System;
//класс наследник
namespace TemplateMethod
{
    public class androidphone : PhoneBase
    {
        /// <inheritdoc />
       protected override void CreateHardware()
       {
            Console.WriteLine("Создаем ПО с помощью Google.");
        }

        /// <inheritdoc />
        protected override void Collect()
        {
            Console.WriteLine("Собираем смартфон на заводах партнеров Google");
        }

        /// <inheritdoc />
        protected override void Install()
        {
            Console.WriteLine("Устанавливаем android ПО.");
        }

        /// <summary>
        /// Приведение объекта к строке.
        /// </summary>
        /// <returns> Тип смартфона. </returns>
        public override string ToString()
        {
            return "смартфон на android ";
        }
    }
}
